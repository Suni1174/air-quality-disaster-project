"""
=============================================================
MODEL VALIDATION — Against Real Historical Events
Team Thunderstorm | AQI Disaster Intelligence

TWO checks per event:
  1. Label Match%  — did we correctly label these dates?
  2. Model Match%  — did XGBoost actually predict the right
                     event type from the raw satellite data?

The MODEL check is the genuine test. It calls model.predict()
on the actual satellite readings for each event's date window.

Run:  python validate_events.py
=============================================================
"""

import pandas as pd
import numpy as np
from pathlib import Path
import joblib
import warnings
warnings.filterwarnings("ignore")

PROCESSED = Path("data/processed")
MODELS    = Path("models")

LABEL_MAP = {0:"Normal", 1:"Fire", 2:"Dust", 3:"Gas", 4:"Industrial"}

REAL_EVENTS = [
    {"id":1,"city":"Delhi","start":"2019-10-25","end":"2019-11-15","type":"Fire",
     "name":"Delhi Stubble Burning Season 2019",
     "description":"Severe smog from Punjab/Haryana farm fires. AQI crossed 500.",
     "source_name":"Times of India",
     "source_url":"https://timesofindia.indiatimes.com/city/delhi/delhi-air-quality-turns-severe-as-stubble-burning-peaks/articleshow/71815396.cms"},
    {"id":2,"city":"Delhi","start":"2020-11-01","end":"2020-11-20","type":"Fire",
     "name":"Delhi Stubble Burning 2020",
     "description":"Post-lockdown traffic + peak farm fires. AQI exceeded 400.",
     "source_name":"India Today",
     "source_url":"https://www.indiatoday.in/india/story/delhi-air-pollution-stubble-burning-aqi-1740961-2020-11-03"},
    {"id":3,"city":"Delhi","start":"2021-10-28","end":"2021-11-12","type":"Fire",
     "name":"Delhi Diwali + Stubble Crisis 2021",
     "description":"Firecrackers combined with farm fires pushed AQI to 500+.",
     "source_name":"The Hindu",
     "source_url":"https://www.thehindu.com/news/cities/Delhi/delhi-air-quality-remains-very-poor/article37261858.ece"},
    {"id":4,"city":"Delhi","start":"2022-10-30","end":"2022-11-14","type":"Fire",
     "name":"Delhi Stubble Burning Season 2022",
     "description":"SAFAR reported farm fires contributing 40%+ of PM2.5 load.",
     "source_name":"Hindustan Times",
     "source_url":"https://www.hindustantimes.com/cities/delhi-news/delhi-aqi-pollution-stubble-burning-diwali-2022-101667474793143.html"},
    {"id":5,"city":"Delhi","start":"2023-10-25","end":"2023-11-10","type":"Fire",
     "name":"Delhi Stubble Burning Season 2023",
     "description":"Despite SC orders, farm fires caused severe AQI in Delhi NCR.",
     "source_name":"NDTV",
     "source_url":"https://www.ndtv.com/india-news/delhi-air-quality-pollution-stubble-burning-aqi-4564890"},
    {"id":6,"city":"Jaipur","start":"2019-05-18","end":"2019-05-22","type":"Dust",
     "name":"Rajasthan Dust Storm May 2019",
     "description":"PM10 exceeded 1500 ug/m3 in Jaipur during Loo season.",
     "source_name":"Times of India Jaipur",
     "source_url":"https://timesofindia.indiatimes.com/city/jaipur/dust-storm-hits-jaipur-pm10-level-shoots-up/articleshow/69390422.cms"},
    {"id":7,"city":"Jaipur","start":"2020-05-25","end":"2020-05-28","type":"Dust",
     "name":"Rajasthan Dust Storm May 2020",
     "description":"Severe dust storm during lockdown, Jaipur/Jodhpur/Bikaner.",
     "source_name":"IMD India",
     "source_url":"https://mausam.imd.gov.in"},
    {"id":8,"city":"Jaipur","start":"2021-06-02","end":"2021-06-05","type":"Dust",
     "name":"Rajasthan Dust Storm June 2021",
     "description":"Pre-monsoon dust storm, strong westerly winds, PM10 spike.",
     "source_name":"IMD India",
     "source_url":"https://mausam.imd.gov.in"},
    {"id":9,"city":"Jaipur","start":"2022-05-14","end":"2022-05-17","type":"Dust",
     "name":"Rajasthan Dust Storm May 2022",
     "description":"Visibility under 500m. PM10 > 1200 ug/m3.",
     "source_name":"IMD India",
     "source_url":"https://mausam.imd.gov.in"},
    {"id":10,"city":"Jaipur","start":"2023-05-20","end":"2023-05-24","type":"Dust",
     "name":"Rajasthan Dust Storm May 2023",
     "description":"Dust storm + heatwave. IMD red alert issued.",
     "source_name":"Hindustan Times",
     "source_url":"https://www.hindustantimes.com/india-news/dust-storm-rajasthan-2023-101684731826043.html"},
    {"id":11,"city":"Vizag","start":"2020-05-07","end":"2020-05-09","type":"Gas",
     "name":"LG Polymers Styrene Gas Leak — May 7, 2020",
     "description":"12 deaths, 1000+ hospitalised. India's worst industrial disaster since Bhopal.",
     "source_name":"Wikipedia",
     "source_url":"https://en.wikipedia.org/wiki/2020_Visakhapatnam_gas_leak"},
    {"id":12,"city":"Vizag","start":"2021-06-10","end":"2021-06-12","type":"Industrial",
     "name":"HPCL Vizag Refinery Emission 2021",
     "description":"Elevated SO2/NOx near HPCL refinery. Respiratory complaints reported.",
     "source_name":"CPCB Data",
     "source_url":"https://cpcb.nic.in/automatic-monitoring-data/"},
    {"id":13,"city":"Vizag","start":"2023-03-15","end":"2023-03-17","type":"Industrial",
     "name":"Vizag VSEZ SO2 Spike March 2023",
     "description":"SO2 spike near VSEZ industrial zone, ONGC scheduled flaring.",
     "source_name":"CPCB Data",
     "source_url":"https://cpcb.nic.in/automatic-monitoring-data/"},
    {"id":14,"city":"Vizag","start":"2024-08-21","end":"2024-08-23","type":"Industrial",
     "name":"Escientia Pharma Factory Blast — Aug 21, 2024",
     "description":"MTBE solvent explosion at Atchutapuram SEZ, Anakapalli. 17 killed, 40 injured.",
     "source_name":"Wikipedia",
     "source_url":"https://en.wikipedia.org/wiki/Atchutapuram_pharmaceutical_factory_explosion"},
]


def run_validation():
    # ── Load results parquet (has all columns incl anomaly_score, event_label)
    results_path = PROCESSED / "results.parquet"
    if not results_path.exists():
        raise FileNotFoundError("Run 02_model.py first!")

    df = pd.read_parquet(results_path)
    df["datetime"] = pd.to_datetime(df["datetime"])

    # ── Load the trained XGBoost classifier
    model_path = MODELS / "xgb_classifier.pkl"
    if not model_path.exists():
        raise FileNotFoundError("Run 02_model.py first — model file not found!")

    model, feats = joblib.load(model_path)
    print(f"\n  Model loaded: {len(feats)} features")

    print("""
══ MODEL VALIDATION AGAINST REAL EVENTS ══

  Two checks per event:
    Label%  = % of hours in window that have the correct ground-truth label
    Model%  = % of hours the XGBoost model PREDICTED correctly from raw data

  The Model% is the genuine test.
""")

    header = f"  {'#':<3} {'Event':<40} {'Type':<12} {'Label%':<9} {'Model%':<9} {'Score':<8} {'Result'}"
    print(header)
    print("  " + "─" * 95)

    summary = []
    for ev in REAL_EVENTS:
        mask = (
            (df["city"] == ev["city"]) &
            (df["datetime"] >= ev["start"]) &
            (df["datetime"] <= ev["end"])
        )
        subset = df[mask].copy()

        if subset.empty:
            print(f"  {ev['id']:<3} {ev['name'][:38]:<40} {ev['type']:<12} "
                  f"{'—':<9} {'—':<9} {'—':<8} NO DATA")
            summary.append({**ev, "label_pct":0, "model_pct":0,
                             "peak_score":0, "detected":False})
            continue

        # ── Check 1: Ground truth label match
        label_counts = subset["event_label"].value_counts() \
                       if "event_label" in subset.columns else pd.Series()
        label_pct = label_counts.get(ev["type"], 0) / len(subset) * 100

        # ── Check 2: ACTUAL MODEL PREDICTION
        # Call model.predict() on the raw feature values for this event window.
        # This is what the model sees from the satellite data — no labels involved.
        available = [f for f in feats if f in subset.columns]
        missing   = [f for f in feats if f not in subset.columns]

        X = subset[available].copy()
        for col in missing:          # fill any missing features with 0
            X[col] = 0.0
        X = X[feats].fillna(0)

        raw_preds        = model.predict(X)
        pred_labels      = [LABEL_MAP[int(c)] for c in raw_preds]
        model_correct    = sum(1 for l in pred_labels if l == ev["type"])
        model_pct        = model_correct / len(subset) * 100

        # Peak anomaly score during event
        peak = float(subset["anomaly_score"].max()) \
               if "anomaly_score" in subset.columns else 0.0

        # Event detected if model correctly classified > 50% of hours
        detected = model_pct > 50
        result   = "DETECTED" if detected else "PARTIAL"

        print(f"  {ev['id']:<3} {ev['name'][:38]:<40} {ev['type']:<12} "
              f"{label_pct:6.1f}%  {model_pct:6.1f}%  {peak:.3f}   {result}")

        summary.append({
            **ev,
            "label_pct":  round(label_pct, 1),
            "model_pct":  round(model_pct, 1),
            "peak_score": round(peak, 3),
            "detected":   detected,
        })

    # ── Summary
    n_detected = sum(1 for s in summary if s["detected"])
    n_total    = len(summary)
    print("\n  " + "─" * 95)
    print(f"\n  Model correctly detected: {n_detected}/{n_total} events "
          f"({n_detected/n_total*100:.0f}%)")
    print("""
  Interpretation:
    Label% = 100% for all events means our ground-truth labels are correct.
    Model% = what XGBoost predicted from actual satellite readings on those dates.
    A high Model% proves the ML model genuinely learned the chemical fingerprint
    of each disaster type from the data — not just from the labels.
""")

    # Save
    val_df = pd.DataFrame(summary)
    out    = PROCESSED / "validation_report.parquet"
    val_df.to_parquet(out, index=False)
    print(f"  Validation report saved → {out}")
    return val_df


if __name__ == "__main__":
    run_validation()